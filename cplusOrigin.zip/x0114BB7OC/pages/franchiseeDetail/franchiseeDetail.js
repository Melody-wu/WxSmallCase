
var app = getApp()

Page({
  data: {
    franchiseeId: '',
    franchiseeInfo: {},
    defaultPhoto: '',
    goodsList: [],
    has_goods_type: [],
    onBusiness: true
  },
  form: '',
  page: 1,
  onLoad: function(options){
    var franchiseeId = options.detail,
        that = this,
        defaultPhoto = app.getDefaultPhoto();

    this.setData({
      franchiseeId: franchiseeId,
      defaultPhoto: defaultPhoto
    })
    app.sendRequest({
      url: '/index.php?r=AppShop/GetAppShopByPage',
      data: {
        sub_shop_app_id: franchiseeId
      },
      success: function(res){
        var data = {},
            has_goods_type = res.data[0].has_goods_type;

        data.franchiseeInfo = res.data[0];
        data.onBusiness = res.data[0].is_open == 0 ? false : true;
        if(has_goods_type.length){
          data.has_goods_type = has_goods_type;
          switch(+has_goods_type[0]){
            case 0: that.form = 'goods';
                    data.selectGoodsForm = 'goods';
                    break;
            case 1: that.form = 'appointment';
                    data.selectGoodsForm = 'appointment';
                    break;
          }
          that.getGoodsList();
        }
        that.setData(data);
      }
    })
  },
  onReachBottom: function(){
    if(this.data.has_goods_type.length){
      this.getGoodsList();
    }
  },
  getGoodsList: function(){
    var that = this;
    app.sendRequest({
      url: '/index.php?r=AppShop/getGoodsList',
      data: {
        sub_shop_app_id: this.data.franchiseeId,
        form: this.form,
        page: this.page++
      },
      success: function(res){
        var goodsList = res.data,
            data = {};

        data.goodsList = that.data.goodsList.concat(goodsList);
        that.setData(data);
      }
    })
  },
  turnToGoodsDetail: function (e) {
    let id = e.currentTarget.dataset.id;
    app.turnToPage('/pages/goodsDetail/goodsDetail?detail=' + id + '&franchisee='+ this.data.franchiseeId + '&cart_num=' + this.data.franchiseeInfo.cart_goods_num);
  },
  franchiseeCoverOnload: function(e){
    var _this = this,
        originalWidth = e.detail.width,
        originalHeight = e.detail.height;

    //获取图片的原始长宽
    var windowWidth = 0;
    var imageWidth = 0, imageHeight = 0;

    wx.getSystemInfo({
      success: function (res) {
        windowWidth = res.windowWidth;
        imageWidth = windowWidth;
        imageHeight = imageWidth * originalHeight / originalWidth;
        _this.setData({
          franchiseeCoverWidth: imageWidth,
          franchiseeCoverHeight: imageHeight > imageWidth ? imageWidth : imageHeight
        })
      }
    })
  },
  makePhoneCall: function(e){
    var phone_num = e.currentTarget.dataset.phoneNum;
    app.makePhoneCall(phone_num);
  },
  clickFranchiseeAddress: function(e){
    var dataset = e.currentTarget.dataset,
        eventParams = '';

    app.openLocation({
      latitude: +dataset.lat,
      longitude: +dataset.lng,
      scale: 20
    })
  },
  clickGoodsTab: function(e){
    var dataset = e.currentTarget.dataset,
        form = dataset.form;

    this.form = form;
    this.page = 1;
    this.setData({
      selectGoodsForm: form,
      goodsList: []
    })
    this.getGoodsList();
  }
})
